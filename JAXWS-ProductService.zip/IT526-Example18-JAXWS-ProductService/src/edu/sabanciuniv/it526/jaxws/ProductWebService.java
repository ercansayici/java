package edu.sabanciuniv.it526.jaxws;

import java.util.List;

import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebService;

import edu.sabanciuniv.it526.business.ProductService;
import edu.sabanciuniv.it526.domain.Product;
@WebService
public class ProductWebService 
{
	@EJB
	private ProductService productService;
	
	@WebMethod
	public List<Product> allProducts()
	{
		return productService.getAllProducts();
	}

}
