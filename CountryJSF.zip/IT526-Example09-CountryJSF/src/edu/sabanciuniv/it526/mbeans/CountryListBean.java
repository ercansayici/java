package edu.sabanciuniv.it526.mbeans;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;

import edu.sabanciuniv.it526.domain.Country;
import edu.sabanciuniv.it526.services.CountryService;

@ManagedBean
@SessionScoped
public class CountryListBean {
	
	private List<Country> countries;
	@EJB
	private CountryService countryService;
	
	private Country country;
	private int selectedCountryId = 1;
	
	@PostConstruct
	public void allCountries()
	{
		
		this.countries = countryService.getAllCoutriesFromDB();
		select();
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public List<Country> getCountries() {
		return countries;
	}

	public void setCountries(List<Country> countries) {
		this.countries = countries;
	}

	public int getSelectedCountryId() {
		return selectedCountryId;
	}

	public void setSelectedCountryId(int selectedCountryId) {
		this.selectedCountryId = selectedCountryId;
	}
	
	
	public void select()
	{
		this.country = 
		countryService.getCountryById(this.selectedCountryId);
	}
	
	
	

}
