package edu.sabanciuniv.it526.services;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import edu.sabanciuniv.it526.domain.Country;

@Stateless
public class CountryService {
	@PersistenceContext
	private EntityManager entityManager;
	public List<Country> getAllCoutriesFromDB()
	{
		
		return entityManager.createQuery("select c from Country c",
				Country.class).getResultList();
	}
	public Country getCountryById(int selectedCountryId) {
		
		return entityManager.find(Country.class, selectedCountryId);
	}

}
