package edu.sabanciuniv.it526.mbeans;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;

import edu.sabanciuniv.it526.business.ProductService;
import edu.sabanciuniv.it526.domain.Product;

@ManagedBean
public class AddProductBean {
	
	private Product product = new Product();
	
	@EJB
	private ProductService productService;
	
	public String save()
	{
		//System.out.println(this.product);
		productService.addNewProduct(product);
		return "productlist";
	}
	
	public Product getProduct() {
		return product;
	}



	public void setProduct(Product product) {
		this.product = product;
	}

}
