package edu.sabanciuniv.it526.mbeans;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;

import edu.sabanciuniv.it526.business.ProductService;
import edu.sabanciuniv.it526.domain.Product;

@ManagedBean
public class ProductListBean {
	
	private List<Product> products;
	
	@EJB
	private ProductService productService;
	
	@PostConstruct
	public void allProducts()
	{
		this.products = productService.getAllProducts();
	}
	
	public void delete(int productID)
	{
		productService.deleteProduct(productID);
		this.products=productService.getAllProducts();
	}
	

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	

}
