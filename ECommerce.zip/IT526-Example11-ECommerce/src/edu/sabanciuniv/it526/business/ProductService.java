package edu.sabanciuniv.it526.business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import edu.sabanciuniv.it526.domain.Product;

@Stateless
public class ProductService {

	@PersistenceContext
	private EntityManager entityManager;
	
	public void addNewProduct(Product newProduct)
	{
		entityManager.persist(newProduct);
	}

	public List<Product> getAllProducts() {
		return entityManager
				.createQuery("select p from Product p",Product.class)
				.getResultList();
	}

	public void deleteProduct(int productID) {
		
		Product productToDelete = 
				entityManager.find(Product.class, productID);
		entityManager.remove(productToDelete);
		
	}
}
