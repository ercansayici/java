@javax.xml.bind.annotation.XmlSchema(namespace = "http://tckimlik.nvi.gov.tr/WS", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package tr.gov.nvi.tckimlik.ws;
