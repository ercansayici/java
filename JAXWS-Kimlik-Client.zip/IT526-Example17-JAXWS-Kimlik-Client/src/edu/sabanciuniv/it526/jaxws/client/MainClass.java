package edu.sabanciuniv.it526.jaxws.client;

import tr.gov.nvi.tckimlik.ws.KPSPublic;
import tr.gov.nvi.tckimlik.ws.KPSPublicSoap;

public class MainClass {

	public static void main(String[] args) 
	{
		
		KPSPublicSoap kimlikService = 
				new KPSPublic().getKPSPublicSoap();
		
		boolean sonuc =
		kimlikService.tcKimlikNoDogrula(1L, "AHMET",
				"DEMİRELLİ", 1999);
		
		System.out.println(sonuc);

	}

}
