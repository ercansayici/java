package edu.sabanciuniv.it526.business;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import edu.sabanciuniv.it526.domain.User;



@Stateless
public class UserService {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public boolean checkUser(String uname,String pass)
	{
	  TypedQuery<User> query = 	entityManager
			  .createQuery("select u from User u where"
			  		+ " u.username=:username and"
			  		+ " u.password=:password",User.class);
	  query.setParameter("username", uname);
	  query.setParameter("password", pass);
	  List<User> users =   query.getResultList();
	  
	  if(users==null || users.size()<1)
	  {
		  return false;
	  }
	  return true;
	}

}
