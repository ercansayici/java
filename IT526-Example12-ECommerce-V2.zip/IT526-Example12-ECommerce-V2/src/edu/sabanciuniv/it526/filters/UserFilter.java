package edu.sabanciuniv.it526.filters;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.sabanciuniv.it526.mbeans.LoginBean;


@WebFilter("/secure/*")
public class UserFilter implements Filter {
	
	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		System.out.println("Filter calıştı");
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse res = (HttpServletResponse)response;
		System.out.println( "IP --> "+ req.getRemoteAddr());
		
		
		HttpSession session =   req.getSession();
		
		if( session.getAttribute("loginBean") == null)
		{
			res.sendRedirect("../login.xhtml");
		}
		LoginBean loginBean = (LoginBean) session.getAttribute("loginBean");
		
		if(loginBean.getLoggedIn().equals("false"))
		{
			res.sendRedirect("../login.xhtml");
		}
		
		chain.doFilter(request, response);
	}
	
	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
