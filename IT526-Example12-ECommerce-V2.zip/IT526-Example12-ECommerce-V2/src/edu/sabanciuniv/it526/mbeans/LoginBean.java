package edu.sabanciuniv.it526.mbeans;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import edu.sabanciuniv.it526.business.UserService;

@ManagedBean
@SessionScoped
public class LoginBean {
	
	private String username;
	private String password;
	private String loggedIn = "false";
	
	@EJB
	private UserService userService;
	
	public String login()
	{
		
		
	if(userService.checkUser(username, password))
		{
			this.loggedIn="true";
			return "secure/addproduct";
		}
		return "";
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLoggedIn() {
		return loggedIn;
	}
	public void setLoggedIn(String loggedIn) {
		this.loggedIn = loggedIn;
	}
	
	

}
