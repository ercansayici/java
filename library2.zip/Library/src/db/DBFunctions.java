package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.sql.DataSource;

import model.Author;
import model.Book;
import model.Category;
import model.User;

//example data access

@Named
@RequestScoped
public class DBFunctions {

	private static final String SERVER = "localhost";
	private static final String DATABASE = "library";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "1234";

	public  Connection getConnection() {

		 try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://"
								+ SERVER + "/" + DATABASE, USERNAME,PASSWORD);
			return conn;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
	public User getUserByUsernameAndPassword(String username, String password) {
		
		
		String query = "select * from user u where u.username=? and u.password=?";
		
		try(
				Connection conn = getConnection();
				PreparedStatement psmt = conn.prepareStatement(query);
				) {
				psmt.setString(1, username);
				psmt.setString(2, password);
			    ResultSet rs = psmt.executeQuery();
			    
			    User u = new User();
			    
			    if(rs.next()) {
			    	u.setId(rs.getInt("id"));
			    	u.setUsername(rs.getString("username"));
			    	u.setPassword(rs.getString("password"));
			    }
			    
			    return u;
		
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
		
		
	}
	
	public  List<Book> getBooksByCategoryId(int catid){
		List<Book> books = new ArrayList<Book>();
		String query = "select b.id, b.name, b.year,b.category,b.author, a.name as aname, a.lastname as alastname, a.id as aid, c.name as cname, c.id as cid from book b inner join author a on b.author = a.id inner join category c on b.category=c.id where b.category=?;";
		
		try(
				Connection conn = getConnection();
				PreparedStatement psmt = conn.prepareStatement(query);
				) {
			psmt.setInt(1, catid);
			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				Category cat = new Category(rs.getInt("cid"), rs.getString("cname"));
				Author auhthor = new Author(rs.getInt("aid"),rs.getString("aname"),rs.getString("alastname"));
				
				books.add(
						new Book(rs.getInt("id"),
								rs.getString("name"),
								rs.getInt("year"),
								auhthor, cat
						));
				
				
			}
			
			return books;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public  List<Book> getBooksByAuthorId(int authid){
		List<Book> books = new ArrayList<Book>();
		String query = "select b.id, b.name, b.year,b.category,b.author, a.name as aname, a.lastname as alastname, a.id as aid, c.name as cname, c.id as cid from book b inner join author a on b.author = a.id inner join category c on b.category=c.id where b.author=?;";
		
		try(
				Connection conn = getConnection();
				PreparedStatement psmt = conn.prepareStatement(query);
				) {
			psmt.setInt(1, authid);
			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				Category cat = new Category(rs.getInt("cid"), rs.getString("cname"));
				Author auhthor = new Author(rs.getInt("aid"),rs.getString("aname"),rs.getString("alastname"));
				
				books.add(
						new Book(rs.getInt("id"),
								rs.getString("name"),
								rs.getInt("year"),
								auhthor, cat
						));
				
				
			}
			
			return books;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public  List<Book> getAllBooks(){
		List<Book> books = new ArrayList<Book>();
		String query = "select b.id, b.name, b.year,b.category,b.author, a.name as aname, a.lastname as alastname, a.id as aid, c.name as cname, c.id as cid from book b inner join author a on b.author = a.id inner join category c on b.category=c.id;";
		
		try(
				Connection conn = getConnection();
				PreparedStatement psmt = conn.prepareStatement(query);
				) {

			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				Category cat = new Category(rs.getInt("cid"), rs.getString("cname"));
				Author auhthor = new Author(rs.getInt("aid"),rs.getString("aname"),rs.getString("alastname"));
				
				books.add(
						new Book(rs.getInt("id"),
								rs.getString("name"),
								rs.getInt("year"),
								auhthor, cat
						));
				
				
			}
			
			return books;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	public  List<Category> getCategories(){
		List<Category> categories = new ArrayList<Category>();
		String query = "select * from category";
		
		try(
				Connection conn = getConnection();
				PreparedStatement psmt = conn.prepareStatement(query);
				) {
			
			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				categories.add(
						new Category(rs.getInt("id"), rs.getString("name"))
						);
				
				
			}
			
			return categories;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	public  List<Author> getAuthors(){
		List<Author> authors = new ArrayList<>();
		String query = "select * from author";
		
		try(
				Connection conn = getConnection();
				PreparedStatement psmt = conn.prepareStatement(query);
				) {
			
			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				authors.add(
						new Author(rs.getInt("id"), rs.getString("name"), rs.getString("lastname")))
						;	
				
				
			}
			
			return authors;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public  void saveBook(Book book) {
		String query = "insert into book(name,year,category,author) values(?,?,?,?)";
		try(
				Connection conn = getConnection();
				
				
				) {
			PreparedStatement psmt = conn.prepareStatement(query);
			psmt.setString(1, book.getName());
			psmt.setInt(2, book.getYear());
			psmt.setInt(3, book.getCategory().getId());
			psmt.setInt(4, book.getAuthor().getId());
			psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public  void updateBook(Book book) {
		String query = "update book set name=?, year=?, author=?, category=? where id=?";
		try(
				Connection conn = getConnection();
				
				
				) {
			PreparedStatement psmt = conn.prepareStatement(query);
			psmt.setString(1, book.getName());
			psmt.setInt(2, book.getYear());	
			psmt.setInt(3, book.getAuthor().getId());
			psmt.setInt(4, book.getCategory().getId());
			psmt.setInt(5, book.getId());
			psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	
}
