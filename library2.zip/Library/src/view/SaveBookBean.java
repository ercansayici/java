package view;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DBFunctions;
import model.Author;
import model.Book;
import model.Category;

@Named
@RequestScoped
public class SaveBookBean {

	@Inject LoginBean loginBean;
	@Inject DBFunctions dbFunc;

	private Book bookToSave;
	private List<Author> authors;
	private List<Category> cats;
	
	private List<Book> books;
	
	@PostConstruct
	public void init() {
		
		bookToSave = new Book();
		Author author = new Author();
		Category cat = new Category();
		
		bookToSave.setAuthor(author);
		bookToSave.setCategory(cat);
		
		authors = dbFunc.getAuthors();
		cats = dbFunc.getCategories();
		
		books = dbFunc.getAllBooks();
		
		
		/* This part is no longer needed, as we have a filter...
		if(!loginBean.isLoggedin()) {
			//Redirect user
			
			HttpServletResponse resp=
					(HttpServletResponse)FacesContext
					.getCurrentInstance()
			.getExternalContext().getResponse();
			
			//returns server address +/ project name
			String contextPath = FacesContext
					.getCurrentInstance().getExternalContext()
					.getRequestContextPath();
			
			
			try {
				resp.sendRedirect(contextPath + "/home.jsf");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		*/
		
		
		
	}
	
	
	public String saveBook() {
		
		dbFunc.saveBook(bookToSave);
		init();
		
		return null;
		
	}
	
	
	public Book getBookToSave() {
		return bookToSave;
	}
	public void setBookToSave(Book bookToSave) {
		this.bookToSave = bookToSave;
	}
	
	public List<Author> getAuthors() {
		return authors;
	}
	public void setAuthors(List<Author> authors) {
		this.authors = authors;
	}
	
	public List<Category> getCats() {
		return cats;
	}
	public void setCats(List<Category> cats) {
		this.cats = cats;
	}
	
	public List<Book> getBooks() {
		return books;
	}
}
