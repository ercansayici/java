package view;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import db.DBFunctions;
import model.User;

@Named
@SessionScoped
public class LoginBean implements Serializable{

	@Inject private DBFunctions dbFunc;
	
	private String username;
	private String password;
	private boolean loggedin;
	

	public String logout() {
		
	/*	Clearing all session
	HttpSession sess=	((HttpServletRequest)FacesContext.getCurrentInstance()
					.getExternalContext().getRequest()).getSession();
		
	sess.invalidate();
		
		*/
	
		username = null;
		password = null;
		loggedin = false;
		
		return "home";
		
	}
	
	public String login() {
		
		
		User user = dbFunc.getUserByUsernameAndPassword(username, password);
		
		if(user.getUsername()!=null) {
			System.out.println(user.getUsername());
			loggedin = true;
			return "home";
		}else {
			
			FacesMessage msg = new FacesMessage("Username or pass is wrong!");
			FacesContext.getCurrentInstance().addMessage(null, msg);
					
					
			return null;
		}
		
		
		
	}
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isLoggedin() {
		return loggedin;
	}
	public void setLoggedin(boolean loggedin) {
		this.loggedin = loggedin;
	}
	
	
	
	
	
	
}
