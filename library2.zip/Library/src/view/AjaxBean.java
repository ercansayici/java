package view;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;


//AJAX --> Asynch. Javascript with XMLHttpRequest

@Named
@RequestScoped
public class AjaxBean {

	private String selecteditem;
	private String text;
	
	public String getText() {
		return text;
	}
	
	public void setText(String text) {
		this.text = text;
	}
	
	
	public String getSelecteditem() {
		return selecteditem;
	}
	
	public void setSelecteditem(String selecteditem) {
		this.selecteditem = selecteditem;
	}
}
