package view;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import db.DBFunctions;
import model.Author;

//COntext Dependency Injection (CDI)

@Named
@RequestScoped
public class HomeBean {
	//Context dependency injection
	@Inject DBFunctions dbFunc;
	
	private List<Author> authors;
	
	//Inject does the stuff below:
	/*
	public HomeBean() {
		dbFunc = new DBFunctions();
	}
	*/
	
	@PostConstruct
	public void init() {
		authors = dbFunc.getAuthors();
	}
	
	public List<Author> getAuthors() {
		return authors;
	}
	
}
