package view;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import db.DBFunctions;
import model.Book;

@Named
@RequestScoped
public class BooksBean {
	
	@Inject DBFunctions dbFunc;
	
	private List<Book> books;
	
	
	@PostConstruct
	public void init() {
		
		//Accessing request
		
		 HttpServletRequest req =
				 (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
		
		books = dbFunc.getBooksByAuthorId(Integer.valueOf(req.getParameter("authid")));
				
	}
	
	
	public List<Book> getBooks() {
		return books;
	}
	
	
}
