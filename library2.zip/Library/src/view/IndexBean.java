package view;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class IndexBean {

	private String welcomeMessage = "Library App";
	private int inputNumber;
	

	public IndexBean() {
		
		System.out.println("Constructor call...");
		
		
	}
	
	//called after constructor
	@PostConstruct
	public void init() {
		System.out.println("Init invoked...");
	}
	
	
	public String processInputNumber(int increment) {
		
		System.out.println("Processs input number");
		
		inputNumber +=increment;
		
		
		return null;
	}
	
	public String getWelcomeMessage() {
		return welcomeMessage;
	}
	public void setWelcomeMessage(String welcomeMessage) {
		this.welcomeMessage = welcomeMessage;
	}
	
	public int getInputNumber() {
		return inputNumber;
	}
	
	public void setInputNumber(int inputNumber) {
		this.inputNumber = inputNumber;
	}
	
}
