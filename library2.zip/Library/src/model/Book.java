package model;

public class Book {

	private int id;
	private String name;
	private int year;
	private Author author;
	private Category category;
	
	public Book() {
		// TODO Auto-generated constructor stub
	}
	
	
	

	public Book(int id, String name, int year, Author author, Category category) {
		super();
		this.id = id;
		this.name = name;
		this.year = year;
		this.category = category;
		this.author = author;
	}




	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	
}
