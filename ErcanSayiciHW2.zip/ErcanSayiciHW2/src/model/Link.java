package model;

import java.util.Date;

public class Link {	

	private String username;
	private String postedLink;
	private String title;
	private Date postDate;
	private int viewCount;
	
	
	
	public Link() {
		
	}

	
	public Link(String username, String postedLink, String title, Date postDate, int viewCount) {
		super();
		this.username = username;
		this.postedLink = postedLink;
		this.title = title;
		this.postDate = postDate;
		this.viewCount = viewCount;
	}

	
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPostedLink() {
		return postedLink;
	}

	public void setPostedLink(String postedLink) {
		this.postedLink = postedLink;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getPostDate() {
		return postDate;
	}

	public void setPostDate(Date postDate) {
		this.postDate = postDate;
	}

	public int getViewCount() {
		return viewCount;
	}

	public void setViewCount(int viewCount) {
		this.viewCount = viewCount;
	}
	
	
}
