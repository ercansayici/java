package dbo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.User;
import model.Link;

public class DBFunctions {

	private static final String SERVER 		= "localhost";
	private static final String DATABASE 	= "mylinksdb";
	private static final String USERNAME 	= "root";
	private static final String PASSWORD 	= "123456789";

	
	public  Connection getConnection() {

		 try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://"
								+ SERVER + "/" + DATABASE, USERNAME,PASSWORD);
			return conn;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	

	public User userLogin(String username, String password) {			
			
			String query = "select * from users where username=? and password=?";
			
			try	(	Connection conn = getConnection();
					PreparedStatement psmt = conn.prepareStatement(query);) 
				{
					psmt.setString(1, username);
					psmt.setString(2, password);
				    ResultSet rs = psmt.executeQuery();
				    
				    User u = new User();
				    
				    if(rs.next()) {
				    	u.setUsername(rs.getString("username"));
				    	u.setPassword(rs.getString("password"));
				    }
				    
				    return u;			
				
				} catch (SQLException e) {
				e.printStackTrace();
					}
			
			return null;
			
		}

	
	

	public  void registerUser(User user) {
		
		String query = "insert into users(username,password) values(?,?)";
		
		try	(Connection conn = getConnection();) 
			{
			PreparedStatement psmt = conn.prepareStatement(query);
			psmt.setString(1,user.getUsername());
			psmt.setString(2,user.getPassword());
			
			} catch (SQLException e) {
			e.printStackTrace();
			}
		
		}


	
	public  List<Link> getAllLinks(){
		
		List<Link> links = new ArrayList<Link>();
		String query = "select * from user_links order by viewcount DESC;";
		
			try	(Connection conn = getConnection();
				PreparedStatement psmt = conn.prepareStatement(query);
				) {
	
				ResultSet rs = psmt.executeQuery();
			
				while(rs.next()) {
								
					links.add(
						new Link(rs.getString	("username"),
								rs.getString	("postedlink"),
								rs.getString	("title"),
								rs.getDate		("postdate"),
								rs.getInt		("viewcount")
								
						));		
				
				}
			
				return links;
			
			} catch (SQLException e) {
			e.printStackTrace();
			}
		
		return null;
	}
	
		
	public  List<Link> getLinksByUser(String username){
		
		List<Link> links = new ArrayList<Link>();
		String query = "select * from user_links where username=? order by viewcount DESC;";
		
		try	(	Connection conn = getConnection();
				PreparedStatement psmt = conn.prepareStatement(query);	) 
			{
			psmt.setString(1, username);
			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				links.add(
					new Link(rs.getString("username"),
							rs.getString( "postedlink"),
							rs.getString( "title"),
							rs.getDate("postdate"),
							rs.getInt("viewcount")
								
						));
				
				}
			
				return links;
			
			} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	
	public  void insertLink(Link link) {
		
		String query = "insert into user_links (username, postedlink,title,postdate)\r\n" + 
				"values(?,?,?,now())";
		try(	Connection conn = getConnection(); )
			{
				PreparedStatement psmt = conn.prepareStatement(query);
				psmt.setString(1, link.getUsername());
				psmt.setString(2, link.getPostedLink());
				psmt.setString(3, link.getTitle());
				psmt.setDate(4, (Date) link.getPostDate());
				psmt.setInt(5, link.getViewCount());
				psmt.executeUpdate();
				
			} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
		
			
	public  List<Link> getLinksBySearch(String searchText){
		
		List<Link> links = new ArrayList<Link>();
		String query = "select * from user_links where title like ? order by viewcount DESC;";
		
		try	(	Connection conn = getConnection();
				PreparedStatement psmt = conn.prepareStatement(query); 	) 
			{
			psmt.setString(1, searchText);
			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				links.add(
						new Link(rs.getString	("username"),
								rs.getString	("postedlink"),
								rs.getString	("title"),
								rs.getDate		("postdate"),
								rs.getInt		("viewcount")
								
						));
				
				}
			
			return links;
			
			} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	
	public  void deleteLink(Link link) {
		
		String query = "delete from user_links where username=? and postedlink=?";
		
				try(	Connection conn = getConnection();	)
				{
					PreparedStatement psmt = conn.prepareStatement(query);
					psmt.setString(1, link.getUsername());
					psmt.setString(2, link.getPostedLink());
					psmt.setString(3, link.getTitle());
					psmt.setDate(4, (Date) link.getPostDate());
					psmt.setInt(5, link.getViewCount());
					psmt.executeUpdate();
					
				} catch (SQLException e) {
					e.printStackTrace();
			}
				
	}
	
	
	public void updateViewCount(String link) {
		
		String query = "update user_links set viewcount=viewcount+1 where postedlink=? ";
		try(
				Connection conn = getConnection();
							
			) {
			
			PreparedStatement psmt = conn.prepareStatement(query);
			psmt.setString(1, link);		
			psmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
			
			
}
