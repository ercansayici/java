package view;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;

import db.DBConnections;
import dbo.DBFunctions;
import model.Link;

@Named
@SessionScoped
public class MyLinksBean implements Serializable{
	@Inject
	private LoginBean loginbean;
	@Inject
	private DBFunctions dbCon;
	private List<Link> links;


	@PostConstruct
	public void init() {

		links = dbCon.getLinksByUser(loginbean.getUsername());

	}

	public String delete(Link del) {
		
		dbCon.deleteLink(del.getPostedLink());
		init();
		return "mylinks";
	}
	

	public List<Link> getLinks() {
		return links;
	}
	
}
