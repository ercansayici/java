package view;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import db.DBConnections;
import dbo.DBFunctions;
import model.Link;

@Named
@RequestScoped
public class HomeBean {
	//Context dependency injection
	@Inject 
	DBFunctions dbFunc;

private List<Link> postedlinks;
private String searchTxt;
private boolean searched;
	
	
	
	public HomeBean() {
		dbFunc = new DBFunctions();
	}
	
	
	@PostConstruct
	public void init() {
		postedlinks = dbFunc.getAllLinks();
	}
	
	public List<Link> getAllLinks() {
		return postedlinks;
	}
	
	
	public String search() {

		this.searched = true;
		
		init();
		return null;
	}
	
	public String reset() {
		this.searched = false;
		init();
		return "home";
	}
	
	
	
	
	public void increment() {
		
		
		 HttpServletRequest req =(HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
		 
		 
		 HttpServletResponse resp =(HttpServletResponse)FacesContext.getCurrentInstance().getExternalContext().getResponse();
		 
		
		String str = String.valueOf(req.getParameter("st"));
		
		System.out.println(str);
		
		dbFunc.updateViewCount(str);
		init();
		
		
		try {
			resp.sendRedirect(str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}



	public DBFunctions getDbCon() {
		return dbFunc;
	}



	public void setDbCon(DBFunctions dbCon) {
		this.dbFunc = dbCon;
	}



	public String getSearchStr() {
		return searchTxt;
	}



	public void setSearchStr(String searchTxt) {
		this.searchTxt = searchTxt;
	}



	public boolean isSearched() {
		return searched;
	}



	public void setSearched(boolean searched) {
		this.searched = searched;
	}



	public List<Link> getLinks() {
		return postedlinks;
	}



	public void setLinks(List<Link> links) {
		this.postedlinks = links;
	}
	
	

}
