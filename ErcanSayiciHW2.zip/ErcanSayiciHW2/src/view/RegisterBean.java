package view;

import java.io.Serializable;

import dbo.DBFunctions;

@Named
@RequestScoped
public class RegisterBean implements Serializable {

	@Inject 
	private DBFunctions dbCon;
	
	private String username;
	private String password;
	
	

	public String register() {

		if (dbCon.registerUser(user) == true) 
		{
			FacesMessage msg = new FacesMessage("Please try another username!");
			FacesContext.getCurrentInstance().addMessage(null, msg);
			
			
			
			return null;
		} 
		else 
		
		{
			
			dbCon.registerUser(user);
			FacesMessage msg2 = new FacesMessage("Registered, please go to login page");
			FacesContext.getCurrentInstance().addMessage(null, msg2);

			return null;
		}

	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
