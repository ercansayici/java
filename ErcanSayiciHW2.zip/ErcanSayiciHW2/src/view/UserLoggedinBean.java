package view;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;

import dbo.DBFunctions;;
import model.Link;

@Named
@RequestScoped
public class UserLoggedinBean implements Serializable{
	
	@Inject 
	DBFunctions dbCon;

	private List<Link> links;

	@PostConstruct
	public void init() {
		
		
		 HttpServletRequest req =(HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
		 
		links = dbCon.getUserLinks(String.valueOf(req.getParameter("er")));
			
	}
	
	
	public List<Link> getLinks() {
		return links;
	}


}
