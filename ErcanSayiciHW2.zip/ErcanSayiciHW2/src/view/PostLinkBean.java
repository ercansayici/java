package view;

import java.io.Serializable;

import db.DBConnections;
import dbo.DBFunctions;

@Named
@RequestScoped

public class PostLinkBean implements Serializable {

	@Inject
	LoginBean loginBean;
	@Inject
	DBFunctions dbCon;

	private String title;
	private String link;

	public String postlink() {
		
		
		if( (dbCon. insertLink(loginBean.getUsername(), link)) == false)
		{
		
		dbCon. insertLink(loginBean.getUsername(), link, title);
			
		//dbCon.insLink(loginBean.getUsername(), link,title);
		
		
		return "mylinks";
		}
		else 
		{
			
			FacesMessage msg = new FacesMessage("Link already exists");
			FacesContext.getCurrentInstance().addMessage(null, msg);
					
					
			return null;
		}
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

}
